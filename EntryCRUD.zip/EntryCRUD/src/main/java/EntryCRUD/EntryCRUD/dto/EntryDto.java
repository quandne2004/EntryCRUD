package EntryCRUD.EntryCRUD.dto;


import lombok.Data;

import java.util.Date;

@Data
public class EntryDto {
    private Long id;
    private String title;
    private String content;
    private int rate;
    private Date createdDate;
    private String author;
}
