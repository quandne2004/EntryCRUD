package EntryCRUD.EntryCRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntryCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntryCrudApplication.class, args);
	}

}
