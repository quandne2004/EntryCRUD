package EntryCRUD.EntryCRUD.service;


import EntryCRUD.EntryCRUD.dto.EntryDto;
import EntryCRUD.EntryCRUD.entity.Entry;
import EntryCRUD.EntryCRUD.repository.EntryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Service
public class EntryServiceImpl implements EntryService{

    private final EntryRepository entryRepository;
    @Override
    public EntryDto postEntryDto(EntryDto entryDto) {
         Entry entry = new Entry();
         entry.setRate(entryDto.getRate());
         entry.setAuthor(entryDto.getAuthor());
         entry.setTitle(entryDto.getTitle());
         entry.setCreatedDate(entryDto.getCreatedDate());
         entry.setContent(entryDto.getContent());
        return entryRepository.save(entry).getEntryDto();
    }

    @Override
    public List<EntryDto> getAllEntryDto() {
        return entryRepository.findAll().stream().map(Entry::getEntryDto).collect(Collectors.toList());
    }

    @Override
    public EntryDto updateEntry(Long id, EntryDto entryDto) {
        Optional<Entry> optionalEntry = entryRepository.findById(id);
        if (optionalEntry.isPresent()){
            Entry existingEntry = optionalEntry.get();

            existingEntry.setTitle(entryDto.getTitle());
            existingEntry.setRate(entryDto.getRate());
            existingEntry.setAuthor(entryDto.getAuthor());
            existingEntry.setContent(entryDto.getContent());
            existingEntry.setCreatedDate(new Date());
            return entryRepository.save(existingEntry).getEntryDto();

        }
        return null;
    }

    @Override
    public boolean deleteEntry(Long id) {
        Optional<Entry> optionalEntry = entryRepository.findById(id);
        if (optionalEntry.isPresent()){
            entryRepository.deleteById(id);
            return true;
        }
        return false;
    }


}
