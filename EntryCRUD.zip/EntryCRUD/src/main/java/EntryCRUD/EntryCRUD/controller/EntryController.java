package EntryCRUD.EntryCRUD.controller;


import EntryCRUD.EntryCRUD.dto.EntryDto;
import EntryCRUD.EntryCRUD.entity.Entry;
import EntryCRUD.EntryCRUD.service.EntryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/entry")

@RequiredArgsConstructor
public class EntryController {

    private final EntryService entryService;





    @PostMapping("/post")
    public ResponseEntity<?> postEntry(@RequestBody EntryDto entryDto){
        return ResponseEntity.ok(entryService.postEntryDto(entryDto));
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<EntryDto>> getAllEntry(){
        return ResponseEntity.ok(entryService.getAllEntryDto());
    }




    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateEntry(@PathVariable Long id,@RequestBody EntryDto entryDto){
        EntryDto entry = entryService.updateEntry(id,entryDto);
        if (entry == null){
            return ResponseEntity.notFound().build();
        }else {
            return ResponseEntity.ok().body(entry);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteEntry(@PathVariable Long id){
        boolean success = entryService.deleteEntry(id);
        if (success){
            return ResponseEntity.ok().build();
        }else {
            return ResponseEntity.notFound().build();
        }
    }
}
