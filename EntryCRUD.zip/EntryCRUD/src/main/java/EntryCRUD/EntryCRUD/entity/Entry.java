package EntryCRUD.EntryCRUD.entity;


import EntryCRUD.EntryCRUD.dto.EntryDto;
import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Entity
@Data
@Table(name = "entry")
public class Entry {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String content;
    private int rate;
    private Date createdDate;
    private String author;

    public EntryDto getEntryDto(){
        EntryDto entryDto = new EntryDto();

        entryDto.setId(id);
        entryDto.setTitle(title);
        entryDto.setAuthor(author);
        entryDto.setCreatedDate(createdDate);
        entryDto.setRate(rate);
        entryDto.setContent(content);
        return entryDto;
    }
}
