package EntryCRUD.EntryCRUD.service;

import EntryCRUD.EntryCRUD.dto.EntryDto;

import java.util.List;

public interface EntryService {

    EntryDto postEntryDto(EntryDto entryDto);

    List<EntryDto> getAllEntryDto();

    EntryDto updateEntry(Long id,EntryDto entryDto);

    boolean deleteEntry(Long id);
}
